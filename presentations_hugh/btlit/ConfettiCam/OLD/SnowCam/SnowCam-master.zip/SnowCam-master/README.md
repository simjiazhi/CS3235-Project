SnowCam Experiment
=======

Shows a snow effect over a webcam feed using getUserMedia from WebRTC. Currently works on Firefox Nightly, and latest Chrome.
See [this post](http://ben.periton.co.uk/2012/12/snowcam-a-webrtc-experiment-using-getusermedia/) for more details